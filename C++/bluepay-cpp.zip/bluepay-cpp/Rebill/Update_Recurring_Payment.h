//
//  Update_Recurring_Payment.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Update_Recurring_Payment__
#define __bluepay_cpp__Update_Recurring_Payment__

#include <stdio.h>
void updateRecurringPayment();
#endif /* defined(__bluepay_cpp__Update_Recurring_Payment__) */
