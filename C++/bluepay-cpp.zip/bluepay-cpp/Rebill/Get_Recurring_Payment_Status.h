//
//  Get_Recurring_Payment_Status.h
//  bluepay-cpp
//
 
#ifndef __bluepay_cpp__Get_Recurring_Payment_Status__
#define __bluepay_cpp__Get_Recurring_Payment_Status__

#include <stdio.h>
void getRecurringPaymentStatus();

#endif /* defined(__bluepay_cpp__Get_Recurring_Payment_Status__) */
