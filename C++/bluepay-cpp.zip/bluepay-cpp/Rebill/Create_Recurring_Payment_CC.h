//
//  Create_Recurring_Payment_CC.h
//  bluepay-cpp
//
 
#ifndef __bluepay_cpp__Create_Recurring_Payment_CC__
#define __bluepay_cpp__Create_Recurring_Payment_CC__

#include <stdio.h>
void createRecurringPaymentCC();
#endif /* defined(__bluepay_cpp__Create_Recurring_Payment_CC__) */
