//
//  Cancel_Recurring_Payment.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Cancel_Recurring_Payment__
#define __bluepay_cpp__Cancel_Recurring_Payment__

#include <stdio.h>
void cancelRecurringPayment();
#endif /* defined(__bluepay_cpp__Cancel_Recurring_Payment__) */
