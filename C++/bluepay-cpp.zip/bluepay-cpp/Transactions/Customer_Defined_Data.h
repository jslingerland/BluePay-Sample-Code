//
//  Customer_Defined_Data.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Customer_Defined_Data__
#define __bluepay_cpp__Customer_Defined_Data__

#include <stdio.h>
void customerDefinedData();
#endif /* defined(__bluepay_cpp__Customer_Defined_Data__) */
