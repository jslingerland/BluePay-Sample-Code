//
//  How_To_Use_Token.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__How_To_Use_Token__
#define __bluepay_cpp__How_To_Use_Token__

#include <stdio.h>
void howToUseToken();
#endif /* defined(__bluepay_cpp__How_To_Use_Token__) */
