//
//  Return_Funds.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Return_Funds__
#define __bluepay_cpp__Return_Funds__

#include <stdio.h>
void returnFunds();
#endif /* defined(__bluepay_cpp__Return_Funds__) */
