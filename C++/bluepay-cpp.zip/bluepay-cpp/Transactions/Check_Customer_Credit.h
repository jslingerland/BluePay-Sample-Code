//
//  Check_Customer_Credit.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Check_Customer_Credit__
#define __bluepay_cpp__Check_Customer_Credit__

#include <stdio.h>
void checkCustomerCredit();

#endif /* defined(__bluepay_cpp__Check_Customer_Credit__) */
