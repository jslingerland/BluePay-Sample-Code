//
//  Store_Payment_Information.h
//  bluepay-cpp
//
 
#ifndef __bluepay_cpp__Store_Payment_Information__
#define __bluepay_cpp__Store_Payment_Information__

#include <stdio.h>
void storePaymentInformation();

#endif /* defined(__bluepay_cpp__Store_Payment_Information__) */
