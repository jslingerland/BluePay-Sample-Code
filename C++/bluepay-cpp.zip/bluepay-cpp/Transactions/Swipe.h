//
//  Swipe.h
//  bluepay-cpp
//
//  Created by Patrick Grenning on 6/1/15.
//  Copyright (c) 2015 BluePay Processing. All rights reserved.
//

#ifndef __bluepay_cpp__Swipe__
#define __bluepay_cpp__Swipe__

#include <stdio.h>
void swipe();

#endif /* defined(__bluepay_cpp__Swipe__) */
