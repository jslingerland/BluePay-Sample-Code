//
//  Cancel_Transaction.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Cancel_Transaction__
#define __bluepay_cpp__Cancel_Transaction__

#include <stdio.h>
void cancelTransaction();

#endif /* defined(__bluepay_cpp__Cancel_Transaction__) */
