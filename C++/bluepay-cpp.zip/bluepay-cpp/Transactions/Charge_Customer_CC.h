//
//  Charge_Customer_CC.h
//  bluepay-cpp
//


#ifndef __bluepay_cpp__Charge_Customer_CC__
#define __bluepay_cpp__Charge_Customer_CC__
#include <stdio.h>
void chargeCustomerCC();

#endif /* defined(__bluepay_cpp__Charge_Customer_CC__) */
