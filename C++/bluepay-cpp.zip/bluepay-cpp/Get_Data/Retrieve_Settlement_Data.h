 #ifndef __bluepay_cpp__Retrieve_Settlement_Data__
#define __bluepay_cpp__Retrieve_Settlement_Data__

#include <stdio.h>
void retrieveSettlementData();

#endif /* defined(__bluepay_cpp__Retrieve_Settlement_Data__) */
