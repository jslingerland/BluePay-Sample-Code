//
//  Single_Transaction_Query.h
//  bluepay-cpp
//
 

#ifndef __bluepay_cpp__Single_Transaction_Query__
#define __bluepay_cpp__Single_Transaction_Query__

#include <stdio.h>
void singleTransactionQuery();
#endif /* defined(__bluepay_cpp__Single_Transaction_Query__) */
