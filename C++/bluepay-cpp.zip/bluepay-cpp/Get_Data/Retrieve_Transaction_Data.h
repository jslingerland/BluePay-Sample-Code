//
//  Retrieve_Transaction_Data.h
//  bluepay-cpp
//
 
#ifndef __bluepay_cpp__Retrieve_Transaction_Data__
#define __bluepay_cpp__Retrieve_Transaction_Data__

#include <stdio.h>
void retrieveTransactionData();
#endif /* defined(__bluepay_cpp__Retrieve_Transaction_Data__) */
